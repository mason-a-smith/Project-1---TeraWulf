﻿# Project 1 - Separate Python Files

These are unchanged copies of the Python files from Project1_Final/app, separated for reading and submission.

| File | Purpose |
| --- | --- |
| engine.py | Three-statement forecast and FCFF DCF |
| workbench.py | Bounded assumptions, scenarios, sensitivities and reverse DCF |
| comps.py | Comparable-company multiples |
| validate.py | Finance and model validation tests |
| server.py | Local workbench server |
| build.py | Generate statements, valuation tables and reports |
| cold_run.py | Fresh-environment reproducibility and HTTP tests |
| prepare_documents.py | Format the written documents and memo |
| freeze.py | Create and verify the file manifest and package |

For the runnable product, use the original Project1_Final folder. These files import one another; the server also needs index.html, and the reporting/validation scripts use the original project's evidence, validation and output folders. This code-only collection does not replace the complete project bundle.
