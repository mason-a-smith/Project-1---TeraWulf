"""Prepare readable Markdown and a two-page print-layout memo, no packages."""
from pathlib import Path
import re
from build import render_md
ROOT=Path(__file__).resolve().parents[1]
OWN=['README.md','02_Edition_B.md','06_Decision_Memo.md','07_AI_USE_AND_VALIDATION.md','VIDEO_RECORDING_GUIDE.md',
     'evidence/SOURCE_REGISTER.md','evidence/PEER_POLICY.md','evidence/NORMALIZATION_AND_CONTAMINATION.md']
for name in OWN:
    p=ROOT/name;t=p.read_text(encoding='utf-8')
    t=re.sub(r'\b(January|February|March|April|May|June|July|August|September|October|November|December|Project|Video|Week)(?=\d)',r'\1 ',t)
    t=re.sub(r'(?<=[a-zA-Z])(?=\$\d)',' ',t)
    t=re.sub(r'(?<=\d),(?=20\d{2}\b)',', ',t)
    t=re.sub(r'(?<=\w)(?=\b(?:zero|net)\b)',' ',t)
    p.write_text(t,encoding='utf-8')
memo=(ROOT/'06_Decision_Memo.md').read_text(encoding='utf-8')
split=memo.index('**Value and principal sensitivities.')
def body(md):return render_md(md).split('</style>',1)[1]
pages=[memo[:split],memo[split:]]
css='''@page{size:letter;margin:0.65in}*{box-sizing:border-box}body{font:11pt Georgia,serif;color:#172e3c;margin:0;background:#e7edf0}.page{width:7.2in;min-height:9.65in;background:white;padding:0.2in;margin:20px auto;position:relative;break-after:page}.page:last-child{break-after:auto}h1{font:24pt Arial,sans-serif;color:#125e70;margin:0 0 18px}p{line-height:1.4;margin:0 0 12px}a{color:#125e70;text-decoration:none}footer{font:9pt Arial,sans-serif;color:#547080;margin-top:24px;border-top:1px solid #b8cbd1;padding-top:8px}.toolbar{text-align:center;font:14px Arial;padding:14px}@media print{body{background:white}.page{width:auto;min-height:0;margin:0;padding:0}.toolbar{display:none}}'''
out='<!doctype html><html lang="en"><meta charset="utf-8"><title>WULF committee memo — two-page print layout</title><style>'+css+'</style><div class="toolbar">Two-page memo print layout · Print / Save as PDF using Letter, default100% scale. Browser pagination has not been visually verified in this session.</div>'
for i,p in enumerate(pages,1):out+='<section class="page">'+body(p)+f'<footer>Mason Smith · TeraWulf · October19,2026 · {i}/2</footer></section>'
out+='</html>'
(ROOT/'06_Decision_Memo.html').write_text(out,encoding='utf-8')
print('Prepared Markdown and two-page memo HTML; Edition A and supplied evidence unchanged.')
